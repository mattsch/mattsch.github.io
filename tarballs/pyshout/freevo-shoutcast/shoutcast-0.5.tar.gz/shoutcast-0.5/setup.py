#!/usr/bin/env python

from freevo.util.distribution import setup

setup (name = 'shoutcast',
       version = '0.5',
       description = 'Freevo Shoutcast Stream Plugin',
       author = 'Matthew Schick',
       author_email = 'matt@oss-institute.org',
       url = 'http://matt.schick.homelinux.com/archives/category/projects/python',

      )
