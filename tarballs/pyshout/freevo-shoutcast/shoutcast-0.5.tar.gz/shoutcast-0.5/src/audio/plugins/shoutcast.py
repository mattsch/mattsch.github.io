# Shoutcast plugin for freevo

import menu
import plugin
import time
import config
import rc
import util

from event import *
from py_shoutcast.feeds import ShoutcastFeed
from audio.player import PlayerGUI
from item import Item

class ShoutcastItem(Item):
	"""
	Runs the commands to play our music
	"""
	def actions(self):
		"""
		Returns list of actions
		"""
		items = [ ( self.play, _( 'Tune In to Shoutcast Station' ) ) ]
		return items

	def play(self, arg=None, menuw=None):
		self.elapsed = 0
		if not self.menuw:
			self.menuw = menuw

		self.player=PlayerGUI(self,menuw)
		error=self.player.play()

		if error and menuw:
			AlertBox(text=error).show()
			rc.post_event(rc.PLAY_END)
	
	def stop(self, arg=None, menuw=None):
		self.player.stop()

class ShoutcastMainMenuItem(Item):
	"""
	Creates the Main Menu items
	"""
	def __init__(self, parent):
		Item.__init__(self,parent,skin_type='audio')
		self.name = _( 'Shoutcast Radio' )
		try:
			self.feed_max=int(config.SHOUTCAST_MAX)
		except:
			self.feed_max=500
		try:
			self.min_bitrate=int(config.SHOUTCAST_BITRATE)
		except:
			self.min_bitrate=128
		try:
			self.cache_ttl=int(config.SHOUTCAST_TTL)
		except:
			self.cache_ttl=600
		self.cacheFile=str(config.FREEVO_CACHEDIR)+'/shoutcast'
	def actions(self):
		"""
		Actions for this menu item
		"""
		return [ ( self.generate_genre_menu, 'Genres') ]
	def generate_genre_menu(self,arg=None,menuw=None):
		self.scf=ShoutcastFeed(feed_max=self.feed_max,min_bitrate=self.min_bitrate,cache_ttl=self.cache_ttl,cache_file=self.cacheFile)
		self.feeds=self.scf.parse_stations()
		genre_menus=[]
		genres=self.feeds.keys()
		genres.sort()
		for genre in genres:
			genre_menus.append(menu.MenuItem(genre,action=self.generate_shoutcast_list,arg=self.feeds[genre]))
		genre_menu=menu.Menu( _("Genres"),genre_menus,item_types='audio')
		rc.app(None)
		menuw.pushmenu(genre_menu)
		menuw.refresh()
	def generate_shoutcast_list(self,arg=None,menuw=None):
		stations=arg
		shoutcast_items=[]
		for station in stations:
			shoutcast_item=ShoutcastItem()
			shoutcast_item.player='mplayer'
			shoutcast_item.name=station['Name']
			shoutcast_item.description='Bitrate: '+str(station['Bitrate'])
			shoutcast_item.set_url(station['PLS_URL'])
			shoutcast_item.filename=None
			shoutcast_item.reconect=True
			shoutcast_item.network_play=True
			shoutcast_item.is_playlist=True
			shoutcast_item.mplayer_options=''
			shoutcast_item.bitrate=station['Bitrate']
			shoutcast_item.length=0
			shoutcast_item.remain=0
			#shoutcast_item.elapsed='0:00'
			shoutcast_item.info= {'bitrate': station['Bitrate'],'genre': station['Genres'][0]}
			shoutcast_items+=[shoutcast_item]
		if len(shoutcast_items) == 0:
			shoutcast_items+=[menu.MenuItem( _( 'No Shoutcast Stations Found' ), menuwu.goto_prev_page, 0)]

		shoutcast_menu = menu.Menu( _('Shoutcast Stations'), shoutcast_items,item_types='audio')
		rc.app(None)
		menuw.pushmenu(shoutcast_menu)
		menuw.refresh()

class PluginInterface(plugin.MainMenuPlugin):
	"""
	This plugin will grab a the list of stations from the Shoutcast site
	and display it in the music menu.  Activate with:

	plugin.activate('audio.shoutcast')
	SHOUTCAST_MAX = <int>
	SHOUTCAST_CACHE = <int>
	SHOUTCAST_BITRATE = <int>
	"""	
	def items(self,parent):
		return [ ShoutcastMainMenuItem(parent) ]

	def config(self):
		return [ ('SHOUTCAST_MAX', "500", "Maximimum number of feeds"),
		('SHOUTCAST_TTL', "600", "Use the cache, TTL default is 10 mins, set to 0 to disable"),
		('SHOUTCAST_BITRATE', "128", "Minimum bitrate of feeds") ]
