#!/usr/bin/env python

from freevo.util.distribution import setup

setup (name = 'shoutcast',
       version = '0.7',
       description = 'Freevo Shoutcast Stream Plugin',
       author = 'Matthew Schick',
       author_email = 'matt@excentral.org',
       url = 'https://www.excentral.org/trac/pyshout',
       license='LGPL-2.1',

      )
