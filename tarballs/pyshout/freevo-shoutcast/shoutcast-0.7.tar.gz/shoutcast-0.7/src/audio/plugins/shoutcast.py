# Shoutcast plugin for freevo
# $Id$
# Copyright (C) 2005-2006 Matthew Schick <matt@excentral.org>

# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.

# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.

# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


import menu
import plugin
import time
import config
import rc
import util

from event import *
from py_shoutcast.feeds import ShoutcastFeed, GenreFeed
from audio.player import PlayerGUI
from item import Item
from audio.audioitem import AudioItem
from gui.ProgressBox import ProgressBox

class ShoutcastAudioMenuItem(Item):
    """
    Creates the Audio Menu item
    """
    def __init__(self, parent):
        """
        Sets up the configuration variables
        """
        
        Item.__init__(self,parent,skin_type='audio')
        self.name = _( 'Shoutcast Radio' )
        try:
            self.min_bitrate=int(config.SHOUTCAST_BITRATE)
        except:
            self.min_bitrate=128
        try:
            self.genre_cache_ttl=int(config.SHOUTCAST_GENRE_TTL)
        except:
            self.genre_cache_ttl=3600
        try:
            self.station_cache_ttl=int(config.SHOUTCAST_STATION_TTL)
        except:
	    try:
		self.station_cache_ttl=int(config.SHOUTCAST_TTL)
	    except:
		self.station_cache_ttl=600
        self.cacheDir=str(config.FREEVO_CACHEDIR)+'/shoutcast/'
        
        
    def actions(self):
        """
        Actions for the Main Menu
        """
        return [ ( self.generate_genre_menu, 'Genres') ]
        
        
    def generate_genre_menu(self,arg=None,menuw=None):
        """
        Generates the genre list menu
        """
        
        #Popup a box while fetching feeds, this is because if the fetch is slow
        #Freevo appears to freeze so like the Weather plugin we show we are
        #doing something
        pop = ProgressBox(text=_('Fetching Shoutcast Genres'),full=4)
        pop.show()
        
        #Get raw genre feed in xml from Shoutcast
        self.scf=GenreFeed(self.genre_cache_ttl, self.cacheDir)
        pop.tick()
        
        #Parse the xml to useable form
        self.genres=self.scf.parse_genres()
        pop.tick()
        
        #Create initial variables for menu list and genre list
        genre_menus=[]
        self.genres.sort()
        pop.tick()
        
        #Add menu items for each genre to menu list
        for genre in self.genres:
            genre_menus.append(menu.MenuItem( genre, action=self.generate_shoutcast_list, arg=genre ))
        pop.tick()
            
        #Show genre menu
        genre_menu=menu.Menu( _("Genres"),genre_menus,item_types='audio')
        rc.app(None)
        menuw.pushmenu(genre_menu)
        menuw.refresh()
        pop.destroy()
        
        
    def generate_shoutcast_list(self,arg=None,menuw=None):
        """
        Generates the station list depending on the genre selected
        """
        #Creat initial variables
        genre=arg
        station_items=[]
        
        #Popup a box while fetching feeds, this is because if the fetch is slow
        #Freevo appears to freeze so like the Weather plugin we show we are
        #doing something
        pop = ProgressBox(text=_('Fetching Shoutcast Stations'),full=4)
        pop.show()

        #Get raw genre feed in xml from Shoutcast
        self.scf=ShoutcastFeed(genre, self.min_bitrate, self.station_cache_ttl, self.cacheDir)
        pop.tick()

        #Parse the xml to useable form
        self.stations=self.scf.parse_stations()
        pop.tick()

        self.stations.sort()
        pop.tick()

        #Add station menu items
        for station in self.stations:
            station_item=AudioItem(station['PLS_URL'], self, station['Name'], False)
            station_item.player='mplayer'
            station_item.reconect=True
            station_item.network_play=True
            station_item.is_playlist=True
            station_item.bitrate=station['Bitrate']
            station_item.length=0
            station_item.remain=0
            station_item.info= {'artist': 'Shoutcast Radio' ,'album': None, 'trackno': station['Bitrate'], 'title' : station['Name']}
            station_items+=[station_item]
        
        #If there is no stations found create blank menu with message
        if len(station_items) == 0:
            station_items+=[menu.MenuItem( _( 'No Shoutcast Stations Found' ), menuwu.goto_prev_page, 0)]
        
        #Show genre menu
        shoutcast_menu = menu.Menu( _('Shoutcast Stations'), station_items,item_types='audio')
        rc.app(None)
        menuw.pushmenu(shoutcast_menu)
        menuw.refresh()
        pop.destroy()


class PluginInterface(plugin.MainMenuPlugin):
    """
    This plugin will grab a the list of stations from the Shoutcast site
    and display it in the music menu.  Activate with:

    plugin.activate('audio.shoutcast')
    SHOUTCAST_MAX = <int>
    SHOUTCAST_CACHE = <int>
    SHOUTCAST_BITRATE = <int>
    """ 
    
    def items(self,parent):
        return [ ShoutcastAudioMenuItem(parent) ]

    def config(self):
        return [ ('SHOUTCAST_MAX', "500", "Maximimum number of feeds"),
        ('SHOUTCAST_TTL', "600", "Use the cache, TTL default is 10 mins, set to 0 to disable"),
        ('SHOUTCAST_BITRATE', "128", "Minimum bitrate of feeds") ]
