#!/usr/bin/env python

from freevo.util.distribution import setup

setup (name = 'shoutcast',
       version = '0.6',
       description = 'Freevo Shoutcast Stream Plugin',
       author = 'Matthew Schick',
       author_email = 'matthew.schick@gmail.com',
       url = 'http://www.excentral.org/archives/category/projects/python',

      )
