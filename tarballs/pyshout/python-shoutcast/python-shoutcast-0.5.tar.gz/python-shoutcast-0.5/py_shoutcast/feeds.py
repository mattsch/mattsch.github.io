# pyshout.py - Parses list of Shoutcast stations from Shoutcast.com
# Copyright 2004 Matthew Schick

# This program is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License as published by the Free Software
# Foundation; either version 2 of the License, or (at your option) any later version.

#This program is distributed in the hope that it will be useful, but WITHOUT ANY
#WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
#PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
#You should have received a copy of the GNU General Public License along with
#this program; if not, write to the Free Software Foundation, Inc.,
#59 Temple Place, Suite 330, Boston, MA 02111-1307 USA


import cPickle
from urllib import URLopener
from zlib import decompress
from xml.sax import make_parser,parseString
from xml.sax.handler import ContentHandler
from re import compile,search,I
from encodings.base64_codec import base64_decode
from os import stat
from time import time
from stat import *

tmpxml='shout.xml'
DEBUG=1
genre_regex={
	'Blues':compile('blues',I), 'Classic Rock':compile('classic.rock|classicrock',I),
	'Country':compile('country',I), 'Funk':compile('funk',I), 'Grunge':compile('grunge',I),
	'Hip-Hop':compile('hip.hop|hip',I), 'Jazz':compile('jazz',I), 'Metal':compile('metal',I),
	'New Age':compile('new.age|newage',I), 'Oldies':compile('oldies',I), 'Pop':compile('pop',I),
	'R&B':compile('r.b|rb',I), 'Rap':compile('rap',I), 'Reggae':compile('reggae',I),
	'Rock':compile('rock',I), 'Techno':compile('techno',I), 'Industrial':compile('industrial',I), 
	'Alternative':compile('alternative',I), 'Ska':compile('ska',I), 
	'Soundtrack':compile('sound.track|soundtrack',I), 'Ambient':compile('ambient',I),
	'Trip-Hop':compile('trip.hop|triphop',I), 'Vocal':compile('vocal',I),
	'Fusion':compile('fusion',I), 'Trance':compile('trance',I),
	'Classical':compile('classical',I), 'Instrumental':compile('instrumental',I),
	'Acid':compile('acid',I), 'House':compile('house',I), 'Gospel':compile('gospel',I),
	'Soul':compile('soul',I), 'Punk':compile('punk|punk.rock',I),
	'Meditative':compile('meditative',I), 'Ethnic':compile('ethnic',I), 'Gothic':compile('gothic',I),
	'Electronic':compile('electronic',I), 'Eurodance':compile('eurodance',I),
	'Southern Rock':compile('southern.rock|southernrock',I),
	'Comedy':compile('comedy|pranks|humour|satire',I), 'Gangsta':compile('gangsta',I),
	'Top 40':compile('top.40|top40',I), 'Jungle':compile('jungle',I),
	'New Wave':compile('new.wave|newwave|newave',I), 'Psychadelic':compile('psychadelic',I),
	'Rave':compile('rave',I), 'Showtunes':compile('showtunes',I),'Urban':compile('urban',I),
	'Lo-Fi':compile('lo.fi|lofi',I), 'Tribal':compile('tribal',I),
	'Acid Punk':compile('acid.punk|acidpunk',I), 'Acid Jazz':compile('acid.jazz|acidjazz',I),
	'Polka':compile('polka',I), 'Retro':compile('retro',I), 'Musical':compile('musical',I),
	'Hard Rock':compile('hard.rock|hardrock',I), 'Folk':compile('folk',I),
	'Swing':compile('swing',I), 'Fusion':compile('fusion',I), 'Bebob':compile('bebop|bebop',I),
	'Latin':compile('latin',I), 'Celtic':compile('celtic',I),
	'Bluegrass':compile('bluegrass|blue.grass',I), 'Avantgarde':compile('avantgarde',I),
	'Big Band':compile('big.band|bigband',I), 'Easy Listening':compile('easy.listening',I),
	'Acoustic':compile('acoustic',I), 'Speech':compile('speech',I), 'Opera':compile('opera',I),
	'Chamber Music':compile('chamber.music',I), 'Symphony':compile('symphony',I),
	'Club':compile('club',I), 'Freestyle':compile('freestyle',I),'A Capella':compile('a.capella',I),
	'Euro-House':compile('euro.house',I), 'Dance Hall':compile('dance.hall',I),
	'Goa':compile('goa',I), 'Drum & Bass':compile('drum.&.bass|drum.n.bass|drum.and.bass|bass',I),
	'Hardcore':compile('hardcore',I), 'Indie':compile('indie',I), 'BritPop':compile('britpop',I), 
	'Christian':compile('christian',I), 'Anime':compile('anime',I)
}

class StationParser(ContentHandler):
	"""
	SAX handler for xml feed, not for public consumption
	"""
	def __init__(self,min_bitrate):
		self.isPlaylist=False
		self.isEntry=False
		self.isName=False
		self.isGenre=False
		self.isNowPlaying=False
		self.isListeners=False
		self.isBitrate=False
		self.station_dict={}
		self.min_bitrate=min_bitrate
		self.count=0
	def startElement(self, name, attrs):
		if name == 'playlist':
			self.isPlaylist = True
			self.entry_no = attrs.get('num_entries',None)
			self.label = attrs.get('label',None)
		if name == 'entry':
			self.isEntry = True
			self.pls_url = attrs.get('Playstring',None)
		if name == 'Name':
			self.isName = True
		if name == 'Genre':
			self.isGenre = True
		if name == 'Nowplaying':
			self.isNowPlaying = True
		if name == 'Listeners':
			self.isListeners = True
		if name == 'Bitrate':
			self.isBitrate = True
	def characters(self, chr):
		if self.isName:
			self.Name = chr
		if self.isGenre:
			self.Genres = chr
		if self.isNowPlaying:
			self.NowPlaying = chr
		if self.isListeners:
			self.Listeners = chr
		if self.isBitrate:
			self.Bitrate = chr
	def endElement(self,name):
		if name == 'Name':
			self.isName = False
		if name == 'Genre':
			self.isGenre = False
		if name == 'Nowplaying':
			self.isNowPlaying = False
		if name == 'Listeners':
			self.isListeners = False
		if name == 'Bitrate':
			self.isBitrate = False
		if name == 'entry':
			self.isEntry = False
			if int(self.Bitrate) >= self.min_bitrate:
				self.parse_genres(genre_regex,{'ID':self.count,'Name':self.Name,'PLS_URL':self.pls_url,'Genres':self.Genres,'NowPlaying':self.NowPlaying,'Listeners':self.Listeners,'Bitrate':self.Bitrate})
				self.count += 1
		if name == 'playlist':
			self.isPlaylist = False
			if DEBUG == 1:
				print 'Parsed ',self.count,' stations'
	def parse_genres(self,genre_regex,station):
		"""
		Parses the genres, corrects and classifies based on the genre_regex 
		dictionary
		"""
		for valid_genre in genre_regex:
			if genre_regex[valid_genre].search(station['Genres']):
				if not	self.station_dict.has_key(valid_genre):
					self.station_dict[valid_genre]=[]
				self.station_dict[valid_genre].append(station)
		if len(self.station_dict) == 0:
			if not self.station_dict.has_key('Unknown'):
				self.station_dict['Unknown']=[]
			self.station_dict['Unknown'].append(station)

class ShoutcastFeed:
	def __init__(self,no_compress=0,feed_max=500,min_bitrate=128,cache_ttl=600,cache_file='/tmp/pyshout.cache'):
		"""
		Parses the xml feed and spits out a list of dictionaries with the station info
		keyed by genre. Params are as follows:
		no_compress - O by default, 1 disables zlib compression from shoutcast.com
		feed_max - 500 default, Maximimum number of stations returned
		min_bitrate - 128 default, Minimum bitrate filter
		cache_ttl - 600 default, 0 disables, Seconds cache is considered valid
		cache_file - /tmp/pyshout.cache default, Path to cache file
		"""
		self.no_compress=no_compress
		self.feed_max=feed_max
		self.min_bitrate=min_bitrate
		self.cache_ttl=cache_ttl
		self.cache_file=cache_file
		self.station_dict={}
	def fetch_stations(self):
		"""
		Grabs the xml list of stations from the shoutcast server
		"""
		self.shout_url=base64_decode('aHR0cDovL3Nob3V0Y2FzdC5jb20vc2Jpbi94bWxsaXN0ZXIucGh0bWw/c2VydmljZT1weXNob3V0\n')[0]+'&limit='+str(self.feed_max)+'&no_compress='+str(self.no_compress)
		self.urlhandler=URLopener()
		self.fd=self.urlhandler.open(self.shout_url)
		self.data=self.fd.read()
		self.fd.close()
		if self.no_compress == 0:
			self.stations=decompress(self.data)
		else:
			self.stations=(data)
		return self.stations

	def parse_stations(self):
		self.inv_cache = 0
		self.vc = self.valid_cache()
		if self.cache_ttl > 0 and self.vc != 0:
			if DEBUG == 1:
				print 'Loading cache from ',self.cache_file
			try:
				self.station_dict=self.load_cache()
			except:
				self.inv_cache = 1
		if self.cache_ttl == 0 or self.inv_cache == 1 or self.vc == 0:
			if DEBUG == 1:
				print 'Getting fresh feed'
			parseXML=StationParser(self.min_bitrate)
			self.stations=self.fetch_stations()
			parseString(self.stations,parseXML)
			self.station_dict=parseXML.station_dict
			self.write_cache()
		return self.station_dict

	def write_cache(self):
		"""
		Does a cPickle dump
		"""
		self.fd=open(self.cache_file,'w')
		cPickle.dump(self.station_dict,self.fd,-1)
		self.fd.close()

	def valid_cache(self):
		"""
		See if the cache file exists and is still living
		"""
		try:
			self.mtime=stat(self.cache_file)[ST_MTIME]
		except:
			return 0
		self.curr_time=time()
		if (self.curr_time - self.mtime) > self.cache_ttl:
			return 0
		else:
			return 1
	def load_cache(self):
		"""
		Does a cPickle load
		"""
		self.fd=open(self.cache_file)
		self.station_dict=cPickle.load(self.fd)
		self.fd.close()
		return self.station_dict
