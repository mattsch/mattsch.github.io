#!/usr/bin/env python

from distutils.core import setup

import py_shoutcast

setup(name='python-shoutcast',
	version= py_shoutcast.__version__,
	description='Get shoutcast stream listings',
	author='Matthew Schick',
	author_email='matt@schick.mine.nu',
	url='http://matt.schick.homelinux.com/archives/category/projects/python/',
	license='GPL-2',
	packages=['py_shoutcast'],
)


