#!/usr/bin/env python

from distutils.core import setup

import py_shoutcast

setup(name='python-shoutcast',
	version= py_shoutcast.__version__,
	description='Get shoutcast stream listings',
	author='Matthew Schick',
	author_email='matt@excentral.org',
	url='https://www.excentral.org/trac/pyshout',
	license='LGPL-2.1',
	packages=['py_shoutcast'],
)


